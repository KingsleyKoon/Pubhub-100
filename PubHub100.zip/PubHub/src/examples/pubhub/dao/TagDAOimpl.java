package examples.pubhub.dao;

import java.sql.Connection;
import examples.pubhub.model.Book;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import examples.pubhub.model.Tag;
import examples.pubhub.utilities.DAOUtilities;

public class TagDAOimpl implements TagDAO{
	
	Connection Connection=null;
	PreparedStatement stmt = null;

public List<Tag> getAllTags(){
	
	List<Tag> Tags= new ArrayList<>();

	try {
		Connection = DAOUtilities.getConnection();
		String sql = "SELECT * FROM Tag";			
		stmt = Connection.prepareStatement(sql);	
		
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			Tag tag = new Tag();

			tag.setTag_name(rs.getString("tag_name"));
			
		}
		
		rs.close();
		
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		
		closeResources();
	}
	return Tags;

}


public boolean addTag(String tag_name) {
	
	try {
	
	Connection= DAOUtilities.getConnection();
	String sql = "INSERT INTO public.\"Tag\" values (?)";
	stmt = Connection.prepareStatement(sql);
	
	stmt.setString(1, tag_name);
	
	if (stmt.executeUpdate() != 0)
		return true;
	else
		return false;
} 
	
	catch (SQLException e) {
	e.printStackTrace();
	
	return false;
} 
	finally {
	closeResources();
}
}
	
public boolean removeTag(String tag_name) {
	try {
		Connection = DAOUtilities.getConnection();
		String sql = "DELETE FROM public.\"Tag\" WHERE tag_name=?";
		stmt = Connection.prepareStatement(sql);
		
		stmt.setString(1, tag_name);

		if (stmt.executeUpdate() != 0)
			return true;
		else
			return false;
		
	} catch (SQLException e) {
		e.printStackTrace();
		return false;
	} finally {
		closeResources();
	}
}
public boolean addTagtoBook(String isbn_13, String tag_name) {
	try {
		Connection = DAOUtilities.getConnection();
		String sql= "INSERT INTO public.\"Book_tags\" (isbn_13, tag_name) VALUES (?, ?)";
		stmt = Connection.prepareStatement(sql);
		
		stmt.setString(1,isbn_13);
		stmt.setString(2,tag_name);
		
		if (stmt.executeUpdate() != 0)
			return true;
		else
			return false;
	} catch (SQLException e) {
		e.printStackTrace();
		return false;
	} finally {
		closeResources();
	}
}
public boolean removeTagfromBook(String isbn_13, String tag_name) {
	try {
		Connection = DAOUtilities.getConnection();
		String sql= "DELETE FROM public.\"Book_tags\" WHERE isbn_13=? AND tag_name=?";
		stmt = Connection.prepareStatement(sql);
		
		stmt.setString(1, isbn_13);
		stmt.setString(2, tag_name);
		if (stmt.executeUpdate() != 0)
			return true;
		else
			return false;
	} catch (SQLException e) {
		e.printStackTrace();
		return false;
	} finally {
		closeResources();
	}
}
public List<Tag> getAllTagfromBook(String isbn_13){
	
	List<Tag> tags= new ArrayList<>();
	
	try {
		Connection = DAOUtilities.getConnection();
		String sql="SELECT * FROM public.\"Book_tags\" WHERE isbn_13 = ?";
		stmt= Connection.prepareStatement(sql);
		
		stmt.setString(1, isbn_13);
		
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			Tag tag = new Tag();
			
			tag.setTag_name(rs.getString("tag_name"));
			
			tags.add(tag);
		}
		rs.close();
	}
			catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeResources();
			}
			
			return tags;
}
public List<Book> BookswithTag (String tag_name){
	
	List<Book> bookswithTag= new ArrayList<>();
	
	try {
		Connection = DAOUtilities.getConnection();
		String sql= "SELECT * FROM public.\"Book_tags\" INNER JOIN Books ON public.\"Book_tags\".isbn_13 = Books.isbn_13 WHERE tag_name = ?";
				
		stmt= Connection.prepareStatement(sql);
		
		stmt.setString(1, tag_name);
		
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			Book book = new Book();

			book.setIsbn13(rs.getString("isbn_13"));
			book.setAuthor(rs.getString("author"));
			book.setTitle(rs.getString("title"));
			book.setPublishDate(rs.getDate("publish_date").toLocalDate());
			book.setPrice(rs.getDouble("price"));
			book.setContent(rs.getBytes("content"));
			
			bookswithTag.add(book);
			
	}
		rs.close();
		
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		closeResources();
	}
	
	return bookswithTag;
}

private void closeResources() {
	try {
		if (stmt != null)
			stmt.close();
	} catch (SQLException e) {
		System.out.println("Could not close statement!");
		e.printStackTrace();
	}
	
	try {
		if (Connection != null)
			Connection.close();
	} catch (SQLException e) {
		System.out.println("Could not close connection!");
		e.printStackTrace();
	}
	
}
	
}