package examples.pubhub.dao;
import java.util.List;

import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;


public interface TagDAO {
	
	public List<Tag> getAllTags();
	public boolean addTag(String tag_name) ;
	public boolean removeTag(String tag_name);
	public boolean addTagtoBook(String isbn_13, String tag_name);
	public boolean removeTagfromBook(String isbn_13, String tag_name);
	public List<Tag> getAllTagfromBook(String isbn_13);
	public List<Book> BookswithTag(String tag_name);

}
