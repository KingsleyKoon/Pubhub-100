package examples.pubhub.model;

public class Tag {
	
	private String tag_name;
	

	public Tag() {
		this.tag_name=null;
		
	};
	
	public void setTag_name(String tag_name) {
		this.tag_name=tag_name;
	}
	
	
	public String getTag_name() {
		return tag_name;
		}
}
		

