package examples.pubhub.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.pubhub.dao.TagDAO;
import examples.pubhub.utilities.DAOUtilities;

@WebServlet("/TagRemoving")
public class TagRemovingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String isbn_13= request.getParameter("isbn_13");
		String tag_name= request.getParameter("tag_name");
		TagDAO dao= DAOUtilities.getTagDAO();
		
		boolean tagRemoved= dao.removeTagfromBook(isbn_13, tag_name);
		
		if(tagRemoved==true) {
			request.getSession().setAttribute("message", "Tag successfully removed");
			request.getSession().setAttribute("messageClass", "alert-success");
			request.getRequestDispatcher("addTag.jsp").forward(request, response);
			}
		else {
			request.getSession().setAttribute("message", "There was a problem removing tag");
			request.getSession().setAttribute("messageClass", "alert-danger");
			request.getRequestDispatcher("addTag.jsp").forward(request, response);
	}
}
}